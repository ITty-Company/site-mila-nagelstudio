# BRAND — Mila Nagelstudio (Oosterhout) · бренд-директор 21.11
Лид: leads.csv web/mila-nagelstudio-oosterhout · Waterloostraat 27, 4901 EM Oosterhout · +31 6 43619068 · IG @milanagelstudio.ohout · Salonkee ★4.5 (139 отзывов) · сайта нет.
## Факты
Подтверждено: название, адрес, телефон, IG, рейтинг Salonkee 4.5 / 139 отзывов (leads.csv, источник salonkee.nl/salon/mila-nagelstudio).
Страница Salonkee из цикла не открылась (доступ не подтверждён) → список услуг, цены, часы, имена — НЕ известны. Писать общими словами
(«nagels», «verzorging», «kleur», «nail art» только как слово, без обещаний), цены «op aanvraag», запись — кнопка на Salonkee + телефон.
УТОЧНИТЬ У КЛИЕНТА: услуги и цены, часы, фото работ из IG (разрешение), кто мастер, год открытия. Не путать с «Nail Studio Mila» на Treatwell — не проверено, что это тот же салон.
## 3 концепции
1. «Spiegelglad» — Waterloostraat: вода в имени улицы; хороший ноготь = поверхность тихой воды: ровная, глубокая, отражает свет. Капля лака падает → круги → застывает зеркалом. Настроение: тихо, точно, прохладный утренний свет.
2. «Slotjesstad» — Oosterhout зовут городом «slotjes» (маленьких замков): каждый ноготь — маленький замок, защищённый и сделанный с точностью. Настроение: геральдика, камень, торжественно.
3. «Tien kleine doeken» — десять ногтей как десять маленьких холстов, мастерская художника, мазки. Настроение: арт-студия.
ВЫБОР: №1. Растёт из реального адреса и из самого ремесла (слой за слоем до зеркального блеска), даёт готовый процесс для скролла и материал,
который LTX отлично анимирует без рук (капля, круги на воде, глянец). №2 красив, но «замок» плохо связан с ногтями и уводит в музей;
№3 — близко к high-quality-nails (лак/цвет как живопись) и dolche-beauty. Вода/зеркало не было ни у одного прошлого сайта (ногтевые: лакрек и окно HQN,
сахарная глазурь Dolché, нефрит+папайя DF, золото Golden Fingers).
Большая идея: **«Spiegelglad, laag voor laag»** — ноготь доводится до тишины воды: от ряби к зеркалу.
## Визуальный мир и стиль кадров (gpt_image_2_6 → LTX)
Предметы: одиночные накладные типсы миндальной формы (без рук!), лежащие на стекле над мелкой водой; капля лака на кончике кисти (кисть в держателе, не в руке);
круги на воде; гладкие речные камни; лист кувшинки; стеклянная пипетка; маленькая UV-лампа как «луна» над водой; флакон-без-этикетки отражается в воде.
Главы (свет меняется как день над водой): 1 hero «тихая вода, падает капля» (mistwater, утро, туман) → 2 «Vorm»: типса на камне, пилка, пыль как туман (kwikzilver)
→ 3 «Basis»: прозрачный слой, стекло над водой, блики → 4 «Kleur»: капля waterlelie падает в воду и расходится цветом → 5 «Uitharden»: UV-лампа как луна, nachtvijver
→ 6 «Spiegelglad»: готовая типса отражает небо, вода стоит зеркалом → финал «Waterloostraat 27» (сумерки, окна отражаются в воде).
Стиль кадров (один для всех): «quiet still-life on a shallow water mirror, soft overcast morning light from the left, cool sage-grey and mercury tones with a single
deep lily-rose accent, glossy almond nail tips as objects, macro 85mm, eye-level low angle at water surface, gentle mist, perfect reflections, 16:9, generous negative space,
no people, no hands, no fingers, no faces, no text, no logos, no brand bottles». Соседние кадры БЛИЗКИЕ (та же камера у воды, меняется одно действие) — под LTX.
## Палитра (контраст — _notes/contrast.py, WCAG)
| роль | имя | hex |
|---|---|---|
| фон светлых глав | mistwater (туман над водой) | #E5EBE8 |
| текст | slootinkt (тёмная вода) | #12272C |
| акцент, кнопки, ссылки | waterlelie (лак, кувшинка) | #A8325A |
| тёмная глава / UV-ночь | nachtvijver | #0B1A1E |
| атмосфера, ртутный блеск | kwikzilver | #C7D2D1 |
| тёплый блик (только на тёмном / в кадрах) | leliehart | #E8C25E |
| акцент на тёмном | lelienacht | #E58AA6 |
| вторичный текст | muted | #4A5E63 |
Контраст: slootinkt/mistwater 12.85 · waterlelie/mistwater 5.32 · muted/mistwater 5.66 · белый на waterlelie 6.42 · mistwater/nachtvijver 14.72 · leliehart/nachtvijver 10.43 ·
kwikzilver/nachtvijver 11.49 · lelienacht/nachtvijver 7.21 · slootinkt/kwikzilver 10.03. НЕЛЬЗЯ: waterlelie на kwikzilver (4.15), leliehart на светлом (1.41).
Отличие: холодный шалфейно-серый + ртуть + глубокая роза-кувшинка — не совпадает ни с одной строкой journal/palettes.md.
## Шрифты (OFL, woff2 в assets/fonts/, latin + latin-ext → ë ï é; @font-face с unicode-range — из google-fonts-source.css)
- Дисплей: **DM Serif Display 400 + Italic** — глянцевые каплевидные засечки = капля лака. H1 clamp(56px, 12vw, 190px), lh .9, tracking -0.02em;
  строка ломается вручную, курсив-акцент в той же фразе: «Laag voor laag. *Spiegelglad.*»
- Текст: **Commissioner 400/500/600** (variable, один файл на все веса) — 17–18px, lh 1.6, max 60ch.
- Метки/шаги/адрес: **Chivo Mono 400**, 12–13px CAPS, tracking .22em («LAAG 03 / 05»).
Пара не повторяет journal/fonts.md. ui-ux-pro-max предлагал Archivo/Space Grotesk + чёрный — отклонено (безлико, не про воду).
## Логотип
logo.svg — «Mila» DM Serif Display Italic (шрифт вшит base64, файл автономный), точка над ı = миндальная капля лака waterlelie с бликом,
под словом — линия воды и два круга от падения капли; подпись NAGELSTUDIO · OOSTERHOUT (Chivo Mono). favicon.svg — капля + круг на mistwater.
Генератор: _notes/make_logo.py. Для MorphSVG: капля ↔ миндальная типса ↔ эллипс круга.
## Motion-подпись
Фирменный эффект: **«Waterlijn»** — каждый большой заголовок стоит на линии воды, под ним его зеркальное отражение (scaleY(-1), opacity .25, mask-градиент),
которое рябит: SVG feTurbulence + feDisplacementMap, baseFrequency анимируется GSAP от скорости скролла; курсор/тап оставляет круги (canvas ripple)
на hero и на кадрах (WebGL-рябь по изображению, fallback — CSS). На шаге «Spiegelglad» рябь гаснет в ноль — отражение становится чётким (кульминация идеи).
3D (Three.js r170): **«Druppel»** — капля лака MeshPhysicalMaterial (transmission .4, clearcoat 1, color waterlelie, ior 1.5) над водой PlaneGeometry 128×128 с ripple-шейдером
(синус от точки удара, затухание); на скролл капля падает, по воде идут круги, затем капля сплющивается и морфится в миндальную типсу (lerp вершин sphere→almond),
отражение в воде через CubeCamera/RoomEnvironment. Drag — вращать типсу. Fallback: статичный кадр. DPR ≤ 2, пауза вне экрана, reduced-motion → финальный кадр.
Эффекты (≥6, не как у pierrot/up-date/itty): Waterlijn-отражения · капля-прелоадер (падает в логотип, круги = переход страницы: шторка-круг clip-path circle от точки удара) ·
SplitText строки «всплывают» снизу из-под линии воды (y 110%→0, blur 6→0) · счётчик «Laag 0X / 05» ScrambleText · DrawSVG кругов на разделителях ·
горизонтальная лента «Kleurenwater» (капли цвета в стеклянных чашах, без брендов/цен) · cursor-reveal (под курсором кадр становится «сухим/чётким») ·
data-magnetic CTA «Boek via Salonkee» · fit-вордмарк «Mila» в футере с отражением в воде. Без data-count (кроме реальных 4.5 и 139).
Характер: медленный, текучий, без рывков — sine.inOut / power2.out 0.9–1.4s, лёгкий «отскок поверхности» (elastic.out(1,.6)) только у кругов.
## Процесс скроллом (pin + scrub, index)
«Van rimpeling naar spiegel» — 5 шагов, счётчик «LAAG 01 / 05» + вертикальная шкала «глубины» слева, точка-капля опускается по ней:
01 Vorm (типса и пилка, туман пыли) → 02 Basis (прозрачный слой, стекло) → 03 Kleur (капля waterlelie падает) → 04 Uitharden (UV-луна, nachtvijver) → 05 Spiegelglad (вода замирает).
Это общий процесс маникюра, не конкретные услуги студии. Конфигуратор на afspraak.html: «Kies je water» — 3 шага (soort behandeling из списка клиента →
kleurfamilie: helder / nude / rood / donker → afwerking glans/mat) → итог с кнопкой на Salonkee/телефон, цены «op aanvraag». Финал всех страниц — гигантский «Mila» с отражением.
Страницы: index · behandelingen · over-ons (Oosterhout, Waterloostraat, без выдуманной истории) · afspraak · contact.
## Тон текстов (NL)
Rustig · precies · warm-koel (тихо и точно, но по-соседски). Короткие фразы, «je», без восклицаний.
Примеры: «Laag voor laag. *Spiegelglad.*» · «Even stil zitten aan de Waterloostraat — wij doen de rest.» · «139 reviews op Salonkee, gemiddeld 4,5. Lees ze daar zelf.»
